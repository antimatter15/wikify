/* Wikify Bookmarklet
 * (c) Copyright 2008 Antimatter15
 * Prototype 3, Revision 5
 *
 */


(function(){
if(window.Wikify){ //check if already loaded
Wikify.uisave(); //if so, save page
}else{ //if not, load script
var x = document.createElement("script"); //create script tag
x.src = "http://localhost/wikiinternet/c3.js"; //insert absolute HTTP url to script
document.getElementsByTagName("head")[0].appendChild(x); //add to document head
} //end if
})//()


//javascript:(function(){if(window.Wikify){Wikify.uisave()}else{var A=document.createElement("script");A.src="c3.js";document.getElementsByTagName("head")[0].appendChild(A)}})()

if(!window.Wikify){

var Wikify = {

/*START CONFIG*/
saveurl: "http://localhost/wikiinternet/save2.php",
loadurl: "http://localhost/wikiinternet/load2.php",
/*END CONFIG*/

DOMSnapshot: {}, //snapshot of document contents
UIFrame: null, //user interface
DWin: null, //the hack frame pointing to the same location as this page

getID: function(e){ //gets a special identifier for elements
var a=[]; //declare array
while(e!=Wikify.DWin.document.body && !e.id){ //loop until the element has an id
for(var i=0;e.parentNode.childNodes[i]!=e;i++){}//find parent index
a.push(i);//add to array
e = e.parentNode; //set parent
} //end loop
return [a.reverse(),(e.id?e.id:"_xdby")]; //format output
},

fromID: function(a,b){ //get element from identifier
var e = (b=="_xdby")?Wikify.DWin.document.body:Wikify.DWin.document.getElementById(b); //get origin
if((a[0]=="" && a.length == 1) || !a){return e}
while(a.length>0) //loop while a (from id) is not empty
e = e.childNodes[a.splice(0,1)]; //set e to child of itself
//end while loop
return e; //return element
},

sendData: function(url,params,callback){ //create a JSONP request
var script = document.createElement("script"); //create script tag
var head = document.getElementsByTagName("head")[0]; //get head element
var cbk = function(){
//console.log(script)
head.removeChild(script);
if(callback){
callback();
}
}
script.type = "text/javascript"; //set element type
script.src = url+"?"+params; //set src, kill cache
script.onreadystatechange = cbk 
script.onload = cbk
head.appendChild(script); //add to doc head
},

capture: function(){ //captures and returns a snapshot of the DOM
var x = Wikify.DWin.document.getElementsByTagName("*"), s = {}; //declare variables
for(var i = 0; i < x.length; i++){ //loop through all document elements
if(x[i] != Wikify.DWin.document.body && //exclude document body
x[i].id.indexOf("firebug") == -1 &&  //exclude firebug
x[i].tagName.toLowerCase() != "script" && //exclude scripts
x[i].tagName.toLowerCase() != "noscript" && //exclude scripts
x[i].tagName.toLowerCase() != "style" && //exclude styles
x[i].tagName.toLowerCase() != "link" && //exclude styles
//x[i].tagName.toLowerCase() != "a" && //excludes links
x[i].tagName.toLowerCase() != "iframe" && //excludes frames
x[i].tagName.toLowerCase() != "br" && //excludes brs
x[i].innerHTML.indexOf("</") == -1){ //make sure it has no children
//console.log(x[i]);
try{ //continue even on error
var k = Wikify.getID(x[i]); //get element ID
s[k[1]+"</,/>"+k[0].join("</,/>")] = x[i].innerHTML
}catch(err){}; //ignore errors
} //end if
} //end loop
return s; //return snapshot
},

diff: function(){ //diff a current
var s = Wikify.capture(), v=[]; //get DOM snapshot
for(var x in s){ //loop through snaphsot elements
if(s[x] != Wikify.DOMSnapshot[x]){ //check for changes
//console.log(s[x],Wikify.fromID(x.split("</,/>").slice(1),x.split("</,/>")[0]));
v.push(x+"[[]]"+s[x]);
}//end check for changes
}//end loop
Wikify.DOMSnapshot = s; //update snapshot
//console.log(v);
return v.join("<!!!>"); //return processed diff
},

save: function(){ //save data to server
Wikify.setEditable(false)
var a = Wikify.diff(); //get diff
if(a != ""){ //if it's not empty
//console.log("SAVED");
Wikify.setEditable(false)
setTimeout(function(){
Wikify.setEditable(false)
Wikify.sendData(Wikify.saveurl, "url="+escape(window.location.href)+"&dat="+escape(escape(a)));
},100);
}else{
return true
}
},

load: function(){ //try getting/loading data from server
Wikify.sendData(Wikify.loadurl, "url="+escape(window.location.href)+"&ck="+escape(Math.round(Math.random()*99999).toString()));
},

parse: function(q){ //parse output from server
q = unescape(q); //unescape data
var w = q.split("<!!!>"); //split changes
for(var i = 0;i < w.length; i++){ //loop through changes
try{ //ignore errors
var f = w[i].split("[[]]"), //split contnet
u = f[0].split("</,/>") //decrypt ID
Wikify.fromID(u.slice(1),u[0]).innerHTML = f[1]; //set element contents
}catch(err){
//console.error(err)
}; //ignore errors
} //end loop
},
setEditable: function(option){
if(option==true){
Wikify.DWin.document.designMode = "on";
}else if(option == false){
Wikify.DWin.document.designMode = "off";
}
},

createUI: function(){ //EXPERIMENTAL!
var dochtml = document.getElementsByTagName("html")[0].innerHTML
document.body.innerHTML = "";

var p = document.createElement("iframe");
p.setAttribute("style","border:0;position:absolute;left: 0;top:0;width:100%;height:100%;background-color:#fff");
document.body.appendChild(p);
p = (p.contentWindow)? p.contentWindow: (p.contentDocument.document)? p.contentDocument.document: p.contentDocument
p.document.open();
p.document.write(dochtml.replace(/script/g,"noscript")); //murder scripts
p.document.close();

p.onload = function(){
window.top.Wikify.load();
}
Wikify.DWin = p

var i = document.createElement("iframe");
i.setAttribute("style","border:0;position:fixed;right: 0;top:0;width:235px;height:20px;background-color:#fff");
document.body.appendChild(i);
i = (i.contentWindow)? i.contentWindow: (i.contentDocument.document)? i.contentDocument.document: i.contentDocument;
i.document.open();
i.document.write('<style>a{text-decoration:none;color:#fff} span{color:#FFFF00} #status{color:#66FF00}</style><script>function status(t){document.getElementById("status").innerHTML=t}</script><div style="width: 100%; height: 100%; position: absolute; top: 0; left: 0; background-color: #0099FF"><span>&nbsp;Wikify&nbsp;-&nbsp;</span><span id="status">Loading</span><span style="right:3px;position:absolute"><a href="javascript:window.top.Wikify.uisave()">Save</a> <a href="javascript:window.top.Wikify.uiabout()">About</a> <a href="javascript:window.top.Wikify.uihelp()">Help</a></span></div>');
i.document.close();
Wikify.UIFrame = i;

},
uisave: function(){
Wikify.UIFrame.status("Saving")
if(Wikify.save()==true)
Wikify.uisaved() //it's already saved if its empty
},
uisaved: function(){
Wikify.UIFrame.status("Saved")
//console.log("SAVED");
Wikify.setEditable(true)
},
uiabout: function(){
alert("(C) Antimatter15 2008\n If you are an angry webmaster, please email me at antimatter15@gmail.com but don't hold me responsible for actions done by users.");
},
uihelp: function(){
alert("Simply run the bookmarklet from any web page. Be warned, it's terribly glitchy, edits won't be stored if they involve deleting an element or if it's in a paragraph with images or other HTMl tags in it.\n Wikify Bookmarklet Prototype 3, Revision 5");
},
uiloaded: function(){
Wikify.UIFrame.status("Loaded")
}
}

//Wikify.load();

if(window.top == window){
Wikify.createUI();
}else{
//window.top.Wikify.load();
}

}
//alert("Wikify (C) Antimatter15 2008 \n Click on the Wikify bookmarklet again to save edits");
